pushd test
rm bin.dat
./../bin/swifter_tu4 && ./../bin/tool_follow
popd